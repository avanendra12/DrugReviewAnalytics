# DrugReviewAnalytics

A deep learning-based project to analyze drug performance using UCI Drug Review data and FDA metadata.

## Overview
This project evaluates drug effectiveness and sentiment trends by:
- Performing sentiment analysis on reviews.
- Scoring symptom-specific performance.
- Calculating effectiveness scores (rating, sentiment, aging).
- Tracking temporal sentiment trends.
- Training LSTM, GRU, and CNN models to predict effectiveness.