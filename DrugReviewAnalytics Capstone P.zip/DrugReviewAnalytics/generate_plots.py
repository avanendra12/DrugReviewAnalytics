import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense
from tensorflow.keras.optimizers import Adam

# Define paths
OUTPUT_DIR = "outputs"
PLOT_DIR = "plots"
EFFECTIVENESS_CSV = os.path.join(OUTPUT_DIR, "drug_effectiveness.csv")
TEMPORAL_CSV = os.path.join(OUTPUT_DIR, "temporal_sentiment.csv")
MODEL_CSV = os.path.join(OUTPUT_DIR, "model_results.csv")
SENTIMENT_CSV = os.path.join(OUTPUT_DIR, "Sentiment_Analysis_and_Symptom_Specific_Scoring.csv")

# Create plot directory
os.makedirs(PLOT_DIR, exist_ok=True)

# Set plot style
plt.style.use('dark_background')
sns.set_style("darkgrid", {"axes.facecolor": "#333333", "axes.edgecolor": "#00ccff", 
                           "xtick.color": "#ffffff", "ytick.color": "#ffffff"})

# Histogram for Effectiveness Scores
def plot_effectiveness_histogram():
    df = pd.read_csv(EFFECTIVENESS_CSV)
    fig, ax = plt.subplots(figsize=(6, 4))
    sns.histplot(df['effectiveness_score'], bins=10, color='#00ccff', ax=ax)
    ax.set_title("Drug Effectiveness Distribution", color='#ffffff', fontsize=14)
    ax.set_xlabel("Effectiveness Score", color='#ffffff', fontsize=12)
    ax.set_ylabel("Count", color='#ffffff', fontsize=12)
    ax.set_facecolor('#333333')
    fig.set_facecolor('#1a1a1a')
    plt.savefig(os.path.join(PLOT_DIR, "effectiveness_histogram.png"), 
                bbox_inches='tight', facecolor='#1a1a1a')
    plt.close()
    print("Effectiveness histogram saved.")

# Line Plot for Temporal Sentiment (VALSARTAN)
def plot_temporal_trend():
    df = pd.read_csv(TEMPORAL_CSV)
    drug_df = df[df['drugName'].str.upper() == 'VALSARTAN']
    if drug_df.empty:
        print("No data for VALSARTAN.")
        return
    fig, ax = plt.subplots(figsize=(6, 4))
    sns.lineplot(x='review_year', y='smoothed_sentiment', data=drug_df, 
                 marker='o', color='#00ccff', ax=ax)
    ax.set_title("Sentiment Trend: VALSARTAN", color='#ffffff', fontsize=14)
    ax.set_xlabel("Year", color='#ffffff', fontsize=12)
    ax.set_ylabel("Sentiment", color='#ffffff', fontsize=12)
    ax.set_facecolor('#333333')
    fig.set_facecolor('#1a1a1a')
    plt.savefig(os.path.join(PLOT_DIR, "temporal_trend_valsartan.png"), 
                bbox_inches='tight', facecolor='#1a1a1a')
    plt.close()
    print("Temporal trend plot saved.")

#  Bar Chart for Model Performance
def plot_model_performance():
    df = pd.read_csv(MODEL_CSV)
    fig, ax = plt.subplots(figsize=(6, 4))
    sns.barplot(x='model', y='accuracy', data=df, color='#00ccff', ax=ax)
    ax.set_title("Model Performance", color='#ffffff', fontsize=14)
    ax.set_xlabel("Model", color='#ffffff', fontsize=12)
    ax.set_ylabel("Accuracy", color='#ffffff', fontsize=12)
    ax.set_facecolor('#333333')
    fig.set_facecolor('#1a1a1a')
    plt.savefig(os.path.join(PLOT_DIR, "model_performance_bar.png"), 
                bbox_inches='tight', facecolor='#1a1a1a')
    plt.close()
    print("Model performance bar chart saved.")

# Heatmap for CNN Confusion Matrix
def plot_cnn_confusion_matrix():
    df = pd.read_csv(SENTIMENT_CSV)
    reviews = df['review'].astype(str)
    labels = (df['effectiveness_score'] > df['effectiveness_score'].median()).astype(int)
    
    tokenizer = Tokenizer(num_words=5000)
    tokenizer.fit_on_texts(reviews)
    sequences = tokenizer.texts_to_sequences(reviews)
    X = pad_sequences(sequences, maxlen=100)
    X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2, random_state=42)
    vocab_size = len(tokenizer.word_index) + 1

    model = Sequential([
        Embedding(vocab_size, 128),
        Conv1D(64, 5, activation='relu'),
        GlobalMaxPooling1D(),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    model.fit(X_train, y_train, epochs=5, batch_size=32, verbose=1)
    
    y_pred = (model.predict(X_test) > 0.5).astype(int)
    cm = confusion_matrix(y_test, y_pred)
    
    fig, ax = plt.subplots(figsize=(6, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax, cbar=False)
    ax.set_title("CNN Confusion Matrix", color='#ffffff', fontsize=14)
    ax.set_xlabel("Predicted", color='#ffffff', fontsize=12)
    ax.set_ylabel("Actual", color='#ffffff', fontsize=12)
    ax.set_facecolor('#333333')
    fig.set_facecolor('#1a1a1a')
    ax.tick_params(colors='#ffffff')
    plt.savefig(os.path.join(PLOT_DIR, "cnn_confusion_matrix.png"), 
                bbox_inches='tight', facecolor='#1a1a1a')
    plt.close()
    print("CNN confusion matrix saved.")

# Run all plots
if __name__ == "__main__":
    print("Generating plots for slides...")
    plot_effectiveness_histogram()
    plot_temporal_trend()
    plot_model_performance()
    plot_cnn_confusion_matrix()
    print("All plots generated in plots/ folder.")