import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from flask import Flask, request, render_template
import io
import base64
import os

app = Flask(__name__, template_folder='templates')

DATA_DIR = "data"
OUTPUT_DIR = "outputs"
SENTIMENT_CSV = os.path.join(OUTPUT_DIR, "Sentiment_Analysis_and_Symptom_Specific_Scoring.csv")
EFFECTIVENESS_CSV = os.path.join(OUTPUT_DIR, "drug_effectiveness.csv")
TEMPORAL_CSV = os.path.join(OUTPUT_DIR, "temporal_sentiment.csv")
MODEL_CSV = os.path.join(OUTPUT_DIR, "model_results.csv")

df = pd.read_csv(SENTIMENT_CSV)
eff_df = pd.read_csv(EFFECTIVENESS_CSV)
temporal_df = pd.read_csv(TEMPORAL_CSV)
model_df = pd.read_csv(MODEL_CSV)

def plot_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight', facecolor='#1a1a1a', edgecolor='none')
    buf.seek(0)
    img_str = base64.b64encode(buf.getvalue()).decode('utf-8')
    buf.close()
    return img_str

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/dashboard')
def dashboard():
    drug = request.args.get('drug', '').strip()
    drug_upper = drug.upper()
    if drug_upper not in df['drugName'].str.upper().values:
        return "Drug not found! <a href='/'>Go back</a>", 404

    drug_data = df[df['drugName'].str.upper() == drug_upper]
    condition = drug_data['condition'].iloc[0]
    effectiveness = drug_data['effectiveness_score'].mean() if 'effectiveness_score' in drug_data else 0.0
    sentiment = drug_data['sentiment_score'].mean()
    symptom_score = drug_data['symptom_score'].mean() if 'symptom_score' in drug_data else 0.0
    review_count = len(drug_data)
    description = f"{drug} is used for {condition}, based on {review_count} reviews."

    fig, ax = plt.subplots(figsize=(6, 4))
    sns.histplot(drug_data['effectiveness_score'], bins=10, color='#00ccff', ax=ax)
    ax.set_title(f"Effectiveness: {drug}", color='white')
    ax.set_xlabel("Score", color='white')
    ax.set_ylabel("Count", color='white')
    ax.set_facecolor('#333333')
    fig.set_facecolor('#1a1a1a')
    ax.tick_params(colors='white')
    eff_plot = plot_to_base64(fig)
    plt.close()

    drug_trend = temporal_df[temporal_df['drugName'].str.upper() == drug_upper]
    trend_plot = ""
    if not drug_trend.empty:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(drug_trend['review_year'], drug_trend['smoothed_sentiment'], marker='o', color='#00ccff')
        ax.set_title(f"Sentiment Trend: {drug}", color='white')
        ax.set_xlabel("Year", color='white')
        ax.set_ylabel("Sentiment", color='white')
        ax.set_facecolor('#333333')
        fig.set_facecolor('#1a1a1a')
        ax.tick_params(colors='white')
        trend_plot = plot_to_base64(fig)
        plt.close()

    fig, ax = plt.subplots(figsize=(6, 4))
    sns.barplot(x='model', y='accuracy', data=model_df, color='#00ccff', ax=ax)
    ax.set_title("Model Performance", color='white')
    ax.set_xlabel("Model", color='white')
    ax.set_ylabel("Accuracy", color='white')
    ax.set_facecolor('#333333')
    fig.set_facecolor('#1a1a1a')
    ax.tick_params(colors='white')
    model_plot = plot_to_base64(fig)
    plt.close()

    return render_template('dashboard.html', drug=drug, condition=condition, 
                          effectiveness=f"{effectiveness:.3f}", sentiment=f"{sentiment:.3f}", 
                          symptom_score=f"{symptom_score:.3f}", review_count=review_count, 
                          description=description, eff_plot=eff_plot, trend_plot=trend_plot, 
                          model_plot=model_plot)

if __name__ == "__main__":
    app.run(debug=False, port=5000)